# Código Python para obtener información del sistema

# Importar modulos necesarios


import json
import socket
import os
import platform
import sys
import sysconfig
import subprocess
import psutil
import requests

# Impresion de datos del sistema

print("="*40, "Host Info" , "="*40)
print("Hostname                    ", socket.gethostname())
print("IP Address                  ", socket.gethostbyname(socket.gethostname()))
print("os.name                     ", os.name)
print("sys.platform                ", sys.platform)
print("platform.system()           ", platform.system())
print("sysconfig.get_platform()    ", sysconfig.get_platform())
print("platform.machine()          ", platform.machine())
print("platform.architecture()     ", platform.architecture())

# A partir de aqui se comienza a armar el jsonobject para el host donde se guardará el json Object
# KeysHost= Es el arreglo que contiene todas las etiquetas del json
# valuesHost= Es el arreglo que contiene todos los valores para cada etiqueta(keyHost) del jsonobject

host={}
keysHost=[
    "Hostname",
    "IP Address",
    "os-name ",
    "sys-platform",
    "platform-system",
    "sysconfig-get_platform",
    "platform-machine",
    "platform-architecture"
]
valuesHost=[
     f"{socket.gethostname()}",
     f"{socket.gethostbyname(socket.gethostname())}",
     f"{os.name}",
     f"{sys.platform}",
     f"{platform.system()}",
     f"{sysconfig.get_platform()}",
     f"{platform.machine()}",
     f"{platform.architecture()}",
]

# Una vez que se tiene el arreglo de las etiquetas y valores se procede a armar el jsonObject. El ciclo sirve para unir la etiqueta y el valor

for key, value in zip(keysHost, valuesHost):
    host[key] = value


# Se imprime la información del CPU

print("="*40, "CPU Info", "="*40)

# Número de cores

print("Physical cores:", psutil.cpu_count(logical=False))
print("Total cores:", psutil.cpu_count(logical=True))

# Frecuencias de CPU

cpufreq = psutil.cpu_freq()
print(f"Max Frequency: {cpufreq.max:.2f}Mhz")
print(f"Min Frequency: {cpufreq.min:.2f}Mhz")
print(f"Current Frequency: {cpufreq.current:.2f}Mhz")

# Uso del CPU

print("CPU Usage Per Core:")

# En esta parte como recibe un array de datos tenemos que crear la estructura con la misma forma, se declara una variable
# dictionary para guardar la información de core, aprovechando el ciclo que recorre la información

dictionaryCore = {}
keysCore = [
]
for i, percentage in enumerate(psutil.cpu_percent(percpu=True, interval=1)):
    print(f"Core {i} : {percentage}%")
    # Como el nombre de la etiqueta del json es con base en la iteración del ciclo, se guarda en un arreglo primero el valor del porcentaje
    dictionaryCore[i] = f"{percentage}%"
    # En KeysCore se agrega la etiqueta del json iterativa mas el valor del porcentaje, se agrega con un append para que tome la estructura completa con llaves cada etiqueta json y su valor es un objeto en el array
    keysCore.append({f"core{i}": dictionaryCore[i]})
print(f"Total CPU Usage: {psutil.cpu_percent()}%")

cpu = {}
keysCpu = [
    "Physical cores",
    "otal cores",
    "Max Frequency",
    "Min Frequency",
    "Current Frequency",
    "CPU Usage Per Core",
    "Total CPU Usage"

]
valuesCpu = [
    f"{psutil.cpu_count(logical=False)}",
    f"{psutil.cpu_count(logical=True)}",
    f"{cpufreq.max:.2f}Mhz",
    f"{cpufreq.min:.2f}Mhz",
    f"{cpufreq.current:.2f}Mhz",
    keysCore,
    f"{psutil.cpu_percent()}%",

]

for key, value in zip(keysCpu, valuesCpu):
    cpu[key] = value

# Se imprimen los usuario conectados al momento de ejecución del script

usersconn = subprocess.getoutput("who")
print("="*35 , "Usuarios conectados" , "="*35)
print(usersconn)
user={}
keysUser=[
    "user"
]
valuesUser=[
      subprocess.getoutput("who")
]

for key, value in zip(keysUser, valuesUser):
    user[key] = value



# En esta parte se envía información a la API

# Se guarda la url como se está ejecutando desde nuestra maquina da la siguiente IP y el path se define en el código de la API

url = 'http://127.0.0.1:5000/api'

# En la variable pjsonRequest se guardan todos los objectJson con sus respectivas etiquetas

pjsonRequest ={'host': host,'cpu': cpu,'user': user}

# El response guarda lo que le devuelve el metodo request.POST(), en esta parte se envia una petición
# El request a la url y con el jsonrequest que se manda como parámetros
# json=json.dumps(pjsonRequest), en esta parte realizan dos cosas:
# 1.- json= ---> Se guarda en la parte de json la url con la informacion
# 2.-json.dumps(pjsonRequest) ---> La variable es convertida en json

response = requests.post(url, json=pjsonRequest)

# print(response)
if response.status_code == 200: # Cada api debe responderte un código en este caso se evalua el caso exitoso con código 200
    content = response.content # Se guarda la respuesta
    print("Respuesta de API : ")
    print(response)
    print(content)
