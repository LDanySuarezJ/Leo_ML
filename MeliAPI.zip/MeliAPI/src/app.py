
from flask import Flask
from flask import jsonify
from flask import request
import json
import os
from datetime import datetime

app = Flask(__name__)


@app.route('/')
def index():
    return"Hola!!!!"

def error_pag_no_encontrada(error): # Si hay algún path equivocado lanzará este mensaje
    return "<h1>La página que intentas buscar no existe.</h1>"

@app.route('/api', methods=['POST'])# En esta parte se define el path y el metodo de la api rest en este caso es POST por que se recibe un json
def register_jsonText():    
    try: # Try es en caso de presentarse errores)
        print(creacionTxt(request.json)) # En request.json se recibe el json que el cliente envía 
        return jsonify({'mensaje':'ok'}) # si todo salió correctamente se entrega el mensaje "ok"
    except Exception as ex:
        return jsonify({'mensaje': 'Error'})# si hay un bad request, desconexión u otro factor que no depende de la API cae en la excepcion
    

def creacionTxt(resp=""): # Se crea el archivo que contendrá el json
    print("***********") 
    d={}
    print('*************request.json[IP Address]')
    d=request.json['host']
    print(d['IP Address'])
    n=d['IP Address'] 
    print("***********")
    y = json.dumps(resp) # Lo hace legible para que pueda ser escrito en el archivo
    print(y)
    print(resp)   
    file = open(n+'_'+datetime.today().strftime('%Y-%m-%d')+'.csv', 'w')
    file.write(y)
    file.close()
    

if __name__=='__main__':
    app.register_error_handler(404,error_pag_no_encontrada)
    app.run(debug=True)#---> Se utiliza ell modo debug para ver en la terminal lo que recibimos
